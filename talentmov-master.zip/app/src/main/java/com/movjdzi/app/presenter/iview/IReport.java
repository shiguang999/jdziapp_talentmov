package com.movjdzi.app.presenter.iview;

/**
 * @author huangyong
 * createTime 2019-07-09
 */
public interface IReport {
    void loadDone();
    void loadError(String msg);
}
