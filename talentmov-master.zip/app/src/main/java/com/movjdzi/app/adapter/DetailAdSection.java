package com.movjdzi.app.adapter;

/**
 * @author huangyong
 * createTime 2019-09-15
 */
public class DetailAdSection {

}