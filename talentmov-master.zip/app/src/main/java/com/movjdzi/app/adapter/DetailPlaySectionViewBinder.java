package com.movjdzi.app.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.lxj.xpopup.XPopup;
import com.lxj.xpopup.impl.CenterListPopupView;
import com.lxj.xpopup.interfaces.OnSelectListener;
import com.media.playerlib.widget.GlobalDATA;
import com.movjdzi.app.R;
import com.movjdzi.app.adapter.event.OnSeriClickListener;
import com.movjdzi.app.model.VideoVo;

import java.util.ArrayList;

import me.drakeet.multitype.ItemViewBinder;

/**
 * @author huangyong
 * createTime 2019-09-15
 */
public class DetailPlaySectionViewBinder extends ItemViewBinder<DetailPlaySection, DetailPlaySectionViewBinder.ViewHolder> {

    @NonNull
    @Override
    protected ViewHolder onCreateViewHolder(@NonNull LayoutInflater inflater, @NonNull ViewGroup parent) {
        View root = inflater.inflate(R.layout.item_detail_play_section, parent, false);
        return new ViewHolder(root);
    }

    @Override
    protected void onBindViewHolder(@NonNull ViewHolder holder, @NonNull DetailPlaySection detailPlaySection) {
        holder.setData(holder.itemView.getContext(), detailPlaySection.getCommonVideoVo().getMovPlayUrlList().get(0), detailPlaySection.getClickListener(),detailPlaySection.getGroupPlay());
        holder.seeMore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (detailPlaySection.getClickListener() != null) {
                    detailPlaySection.getClickListener().showAllSeri(detailPlaySection.getCommonVideoVo());
                }
            }
        });


        SparseArray<ArrayList<VideoVo>> movPlayUrlList = detailPlaySection.getCommonVideoVo().getMovPlayUrlList();
        String vodPlayFrom = detailPlaySection.getCommonVideoVo().getVodPlayFrom();
        String[] from = vodPlayFrom.split("[$][$][$]");
        holder.playRes.setText("切换线路："+from[detailPlaySection.getGroupPlay()]);
        holder.playRes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CenterListPopupView popupView = new XPopup.Builder(holder.itemView.getContext()).asCenterList("选择播放线路", from, null, 0,
                        new OnSelectListener() {
                            @Override
                            public void onSelect(int position, String text) {
                                holder.setData(holder.itemView.getContext(),
                                        movPlayUrlList.get(position), detailPlaySection.getClickListener(), detailPlaySection.getGroupPlay());
                                detailPlaySection.getClickListener().switchPlay(movPlayUrlList.get(position).get(GlobalDATA.PLAY_INDEX).getPlayUrl(), GlobalDATA.PLAY_INDEX,position);
                                getAdapter().notifyDataSetChanged();
                                detailPlaySection.setGroupPlay(position);
                            }
                        });
                popupView.setCheckedPosition(detailPlaySection.getGroupPlay());
                popupView.show();

            }
        });
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        RecyclerView playList;
        TextView seeMore;
        TextView playRes;

        ViewHolder(View itemView) {
            super(itemView);
            playList = itemView.findViewById(R.id.play_list);
            seeMore = itemView.findViewById(R.id.see_all);
            playRes = itemView.findViewById(R.id.play_res);
        }

        public void setData(Context context, ArrayList<VideoVo> videoVos, OnSeriClickListener clickListener, int groupPlay) {
            PlayListAdapter playListAdapter = new PlayListAdapter(videoVos, clickListener,groupPlay);
            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context);
            linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
            playList.setLayoutManager(linearLayoutManager);
            playList.setAdapter(playListAdapter);
        }
    }

}
