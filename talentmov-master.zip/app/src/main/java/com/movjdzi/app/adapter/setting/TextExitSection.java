package com.movjdzi.app.adapter.setting;

/**
 * @author huangyong
 * createTime 2019-09-18
 */
public class TextExitSection {

}