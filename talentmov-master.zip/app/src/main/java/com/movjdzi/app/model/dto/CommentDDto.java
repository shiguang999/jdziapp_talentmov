package com.movjdzi.app.model.dto;

/**
 * @author huangyong
 * createTime 2019-09-21
 */
public class CommentDDto {

    /**
     * Code : 200
     * Data : 0
     * Msg :
     */

    private int Code;
    private int Data;
    private String Msg;

    public int getCode() {
        return Code;
    }

    public void setCode(int Code) {
        this.Code = Code;
    }

    public int getData() {
        return Data;
    }

    public void setData(int Data) {
        this.Data = Data;
    }

    public String getMsg() {
        return Msg;
    }

    public void setMsg(String Msg) {
        this.Msg = Msg;
    }
}
