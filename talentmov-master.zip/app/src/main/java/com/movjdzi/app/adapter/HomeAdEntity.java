package com.movjdzi.app.adapter;

/**
 * @author huangyong
 * createTime 2019-09-15
 */
public class HomeAdEntity {

    public int getIndex() {
        return index;
    }

    private int index;

    public HomeAdEntity(int index) {
        this.index = index;
    }
}