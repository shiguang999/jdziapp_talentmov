package com.movjdzi.app.adapter.user;

/**
 * @author huangyong
 * createTime 2019-09-17
 */
public class SelfAdSection {

}