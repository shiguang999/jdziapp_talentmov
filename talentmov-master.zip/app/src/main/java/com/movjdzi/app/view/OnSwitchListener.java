package com.movjdzi.app.view;

/**
 * @author huangyong
 * createTime 2019-09-19
 */
public interface OnSwitchListener {
    void switchToHome();

    void switchShare();
}

