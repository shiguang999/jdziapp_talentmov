package com.movjdzi.app.adapter.user;

/**
 * @author huangyong
 * createTime 2019-09-18
 */
public class TabSection {
    private String funcName;
    private String funImg;

    public String getFuncName() {
        return funcName;
    }

    public void setFuncName(String funcName) {
        this.funcName = funcName;
    }

    public String getFunImg() {
        return funImg;
    }

    public void setFunImg(String funImg) {
        this.funImg = funImg;
    }

    public int getFuncId() {
        return funcId;
    }

    public void setFuncId(int funcId) {
        this.funcId = funcId;
    }

    private int funcId;

}
